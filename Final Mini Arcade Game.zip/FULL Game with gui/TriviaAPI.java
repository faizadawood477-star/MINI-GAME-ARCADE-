import org.json.JSONArray;
import org.json.JSONObject;
import java.net.http.*;
import java.net.URI;
import java.util.*;

public class TriviaAPI {
    public List<TriviaQuestion> getQuestions(int amount) {
        List<TriviaQuestion> questions = new ArrayList<>();
        String apiUrl = "https://opentdb.com/api.php?amount=" + amount;

        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                JSONObject jsonResponse = new JSONObject(response.body());
                if (jsonResponse.getInt("response_code") == 0) {
                    JSONArray results = jsonResponse.getJSONArray("results");
                    for (int i = 0; i < results.length(); i++) {
                        JSONObject q = results.getJSONObject(i);

                        JSONArray incorrectAnswers = q.getJSONArray("incorrect_answers");
                        String[] incorrect = new String[incorrectAnswers.length()];
                        for (int j = 0; j < incorrect.length; j++) {
                            incorrect[j] = incorrectAnswers.getString(j);
                        }

                        questions.add(new TriviaQuestion(
                            decodeHtmlEntities(q.getString("question")),
                            decodeHtmlEntities(q.getString("correct_answer")),
                            incorrect
                        ));
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error fetching questions: " + e.getMessage());
        }

        return questions;
    }

    private String decodeHtmlEntities(String text) {
        return text.replace("&quot;", "\"")
                  .replace("&amp;", "&")
                  .replace("&lt;", "<")
                  .replace("&gt;", ">")
                  .replace("&#039;", "'");
    }
}

