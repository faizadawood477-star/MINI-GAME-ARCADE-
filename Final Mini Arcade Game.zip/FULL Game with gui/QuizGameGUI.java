import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class QuizGameGUI extends JFrame {
    private JLabel questionLabel, scoreLabel;
    private JButton[] optionButtons;
    private List<TriviaQuestion> questions;
    private int currentIndex = 0;
    private int score = 0;
    private Timer timer;
    private int timeLeft = 15;
    private JProgressBar timerBar;

    public QuizGameGUI() {
        setTitle("🎓 Quiz Game");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Add window listener to handle timer when window loses focus
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowDeactivated(WindowEvent e) {
                stopTimer();
            }

            @Override
            public void windowActivated(WindowEvent e) {
                if (timer != null && !timer.isRunning() && currentIndex < questions.size()) {
                    startTimer();
                }
            }

            @Override
            public void windowClosing(WindowEvent e) {
                stopTimer();
            }
        });

        // Main panel with gradient background
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(0, 0, new Color(100, 149, 237),
                                                    0, getHeight(), new Color(30, 30, 60));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Question label
        questionLabel = new JLabel("Loading questions...", SwingConstants.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 20));
        questionLabel.setForeground(Color.WHITE);
        questionLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 30, 10));

        // Score label
        scoreLabel = new JLabel("Score: 0", SwingConstants.RIGHT);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
        scoreLabel.setForeground(Color.WHITE);

        // Timer progress bar
        timerBar = new JProgressBar(0, 15);
        timerBar.setValue(15);
        timerBar.setForeground(new Color(255, 69, 0));
        timerBar.setStringPainted(true);
        timerBar.setString("15 sec");
        timerBar.setFont(new Font("Arial", Font.BOLD, 12));

        // Top panel with score and timer
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.add(scoreLabel, BorderLayout.WEST);
        topPanel.add(timerBar, BorderLayout.EAST);

        // Option buttons panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 15, 15));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        optionButtons = new JButton[4];

        for (int i = 0; i < 4; i++) {
            optionButtons[i] = createOptionButton();
            buttonPanel.add(optionButtons[i]);
        }

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(questionLabel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel);

        // Load questions in background
        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                questions = new TriviaAPI().getQuestions(10);
                if (questions == null || questions.isEmpty()) {
                    questions = getFallbackQuestions();
                }
                return null;
            }

            @Override
            protected void done() {
                loadQuestion();
            }
        }.execute();
    }

    private JButton createOptionButton() {
        JButton button = new JButton();
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(e -> {
            JButton source = (JButton) e.getSource();
            checkAnswer(source.getText());
        });
        return button;
    }

    private void startTimer() {
        stopTimer(); // Ensure any existing timer is stopped
        timeLeft = 15;
        timerBar.setValue(timeLeft);
        timerBar.setString(timeLeft + " sec");
        timerBar.setForeground(new Color(255, 69, 0));

        timer = new Timer(1000, e -> {
            timeLeft--;
            timerBar.setValue(timeLeft);
            timerBar.setString(timeLeft + " sec");

            if (timeLeft <= 5) {
                timerBar.setForeground(Color.RED);
            }

            if (timeLeft <= 0) {
                stopTimer();
                if (isActive()) { // Only show if window is active
                    JOptionPane.showMessageDialog(this, "Time's up! Moving to next question.");
                }
                currentIndex++;
                loadQuestion();
            }
        });
        timer.start();
    }

    private void stopTimer() {
        if (timer != null) {
            timer.stop();
            timer = null;
        }
    }

    private void loadQuestion() {
        if (currentIndex >= questions.size()) {
            endGame();
            return;
        }

        TriviaQuestion q = questions.get(currentIndex);
        questionLabel.setText("<html><div style='text-align: center; width: 600px; color: white;'>"
                            + q.getQuestion() + "</div></html>");
        String[] options = q.getAllAnswers();

        for (int i = 0; i < optionButtons.length; i++) {
            if (i < options.length) {
                optionButtons[i].setText(options[i]);
                optionButtons[i].setEnabled(true);
                optionButtons[i].setBackground(new Color(70, 130, 180));
            } else {
                optionButtons[i].setText("");
                optionButtons[i].setEnabled(false);
            }
        }

        startTimer();
    }

    private void checkAnswer(String selected) {
        stopTimer();
        TriviaQuestion currentQuestion = questions.get(currentIndex);

        for (JButton btn : optionButtons) {
            btn.setEnabled(false);
            if (btn.getText().equals(currentQuestion.getCorrectAnswer())) {
                btn.setBackground(new Color(34, 139, 34)); // Green for correct
            } else if (btn.getText().equals(selected) &&
                      !selected.equals(currentQuestion.getCorrectAnswer())) {
                btn.setBackground(Color.RED); // Red for wrong selection
            }
        }

        if (selected.equals(currentQuestion.getCorrectAnswer())) {
            score += 10 * (timeLeft + 1); // Bonus for faster answers
            scoreLabel.setText("Score: " + score);
            if (isActive()) { // Only show if window is active
                JOptionPane.showMessageDialog(this, "Correct!", "Result",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            if (isActive()) { // Only show if window is active
                JOptionPane.showMessageDialog(this,
                    "Incorrect! The correct answer was: " + currentQuestion.getCorrectAnswer(),
                    "Result", JOptionPane.ERROR_MESSAGE);
            }
        }

        currentIndex++;
        new Timer(2000, e -> { // Delay before next question
            ((Timer)e.getSource()).stop();
            loadQuestion();
        }).start();
    }

    private void endGame() {
        stopTimer();
        if (isActive()) { // Only show if window is active
            JOptionPane.showMessageDialog(this,
                "Game Over! Your final score: " + score,
                "Quiz Completed", JOptionPane.INFORMATION_MESSAGE);
        }
        dispose();
    }

    private List<TriviaQuestion> getFallbackQuestions() {
        return List.of(
            new TriviaQuestion("What is 2+2?", "4", new String[]{"3", "5", "6"}),
            new TriviaQuestion("Capital of France?", "Paris", new String[]{"London", "Berlin", "Rome"}),
            new TriviaQuestion("Largest planet in our solar system?", "Jupiter", 
                new String[]{"Saturn", "Earth", "Mars"})
        );
    }
}
