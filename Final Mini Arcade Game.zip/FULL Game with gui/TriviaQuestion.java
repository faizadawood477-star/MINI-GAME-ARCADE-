import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TriviaQuestion {
    private String question;
    private String correctAnswer;
    private String[] allAnswers;

    public TriviaQuestion(String question, String correctAnswer, String[] incorrectAnswers) {
        this.question = question;
        this.correctAnswer = correctAnswer;
        this.allAnswers = combineAndShuffleAnswers(correctAnswer, incorrectAnswers);
    }

    private String[] combineAndShuffleAnswers(String correct, String[] incorrect) {
        // Create new array with space for all answers
        String[] combined = new String[incorrect.length + 1];

        // Copy incorrect answers
        System.arraycopy(incorrect, 0, combined, 0, incorrect.length);

        // Add correct answer at the end
        combined[combined.length - 1] = correct;

        // Convert to List for shuffling
        List<String> answerList = Arrays.asList(combined);
        Collections.shuffle(answerList);

        // Convert back to array
        return answerList.toArray(new String[0]);
    }

    public String getQuestion() {
        return question;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public String[] getAllAnswers() {
        return allAnswers;
    }

    // Helper method to decode HTML entities
    public static String decodeHtmlEntities(String text) {
        return text.replace("&quot;", "\"")
                  .replace("&amp;", "&")
                  .replace("&lt;", "<")
                  .replace("&gt;", ">")
                  .replace("&#039;", "'");
    }
}
