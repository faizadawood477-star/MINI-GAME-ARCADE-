import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class RandomGuessingGameGUI extends JFrame {
    private JLabel promptLabel, hintLabel, triesLabel;
    private JTextField guessField;
    private JButton submitBtn;
    private int maxTries = 10, triesLeft;
    private String playerName;
    private Random rand = new Random();

    private enum GameMode { NUMBER, WORD }
    private GameMode currentMode;

    // Number game
    private int targetNumber;

    // Word game
    private final String[] words = {"banana", "guitar", "laptop", "window", "planet", "python", "island", "camera", "rocket", "dragon"};
    private String currentWord, scrambledWord;

    public RandomGuessingGameGUI(String playerName) {
        this.playerName = playerName;
        setTitle("🎮 Random Guessing Game - " + playerName);
        setSize(550, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Mode Selection
        Object[] options = {"Number Guessing", "Scrambled Word Guessing"};
        int modeChoice = JOptionPane.showOptionDialog(
            this, "Choose a Game Mode", "Select Mode",
            JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
            null, options, options[0]);

        currentMode = (modeChoice == 1) ? GameMode.WORD : GameMode.NUMBER;

        // Main panel
        JPanel mainPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(46, 139, 87),
                        0, getHeight(), new Color(30, 30, 60));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Welcome, " + playerName + "!", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        promptLabel = new JLabel("", SwingConstants.CENTER);
        promptLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        promptLabel.setForeground(Color.WHITE);

        hintLabel = new JLabel("", SwingConstants.CENTER);
        hintLabel.setFont(new Font("Arial", Font.BOLD, 20));
        hintLabel.setForeground(new Color(255, 215, 0));
        hintLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        triesLabel = new JLabel("", SwingConstants.CENTER);
        triesLabel.setFont(new Font("Arial", Font.BOLD, 16));
        triesLabel.setForeground(Color.WHITE);

        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        inputPanel.setOpaque(false);

        guessField = new JTextField(10);
        guessField.setFont(new Font("Arial", Font.PLAIN, 18));
        guessField.setHorizontalAlignment(JTextField.CENTER);
        guessField.addActionListener(e -> checkGuess());

        submitBtn = new JButton("Submit");
        styleButton(submitBtn, new Color(70, 130, 180));
        submitBtn.addActionListener(e -> checkGuess());

        inputPanel.add(guessField);
        inputPanel.add(submitBtn);

        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(promptLabel, BorderLayout.CENTER);
        mainPanel.add(hintLabel, BorderLayout.SOUTH);
        mainPanel.add(triesLabel, BorderLayout.WEST);
        mainPanel.add(inputPanel, BorderLayout.EAST);

        add(mainPanel);
        startNewGame();
    }

    private void styleButton(JButton button, Color color) {
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void startNewGame() {
        triesLeft = maxTries;
        triesLabel.setText("Tries left: " + triesLeft);
        guessField.setText("");
        guessField.requestFocus();

        if (currentMode == GameMode.NUMBER) {
            targetNumber = rand.nextInt(100) + 1;
            promptLabel.setText("I'm thinking of a number between 1 and 100");
            hintLabel.setText("Take a guess!");
        } else {
            currentWord = words[rand.nextInt(words.length)];
            scrambledWord = scrambleWord(currentWord);
            promptLabel.setText("Unscramble this word: " + scrambledWord);
            hintLabel.setText("What's the word?");
        }
    }

    private void checkGuess() {
        String input = guessField.getText().trim();
        guessField.setText("");
        guessField.requestFocus();
        if (input.isEmpty()) {
            hintLabel.setText("Please enter something!");
            return;
        }

        triesLeft--;
        triesLabel.setText("Tries left: " + triesLeft);

        if (currentMode == GameMode.NUMBER) {
            try {
                int guess = Integer.parseInt(input);
                if (guess < 1 || guess > 100) {
                    hintLabel.setText("Enter a number between 1-100.");
                    return;
                }

                if (guess == targetNumber) {
                    hintLabel.setText("Correct! It was " + targetNumber);
                    JOptionPane.showMessageDialog(this,
                            "Well done, " + playerName + "! You guessed it in " + (maxTries - triesLeft) + " tries.",
                            "Success!", JOptionPane.INFORMATION_MESSAGE);
                    startNewGame();
                } else if (triesLeft <= 0) {
                    hintLabel.setText("Out of tries! It was " + targetNumber);
                    JOptionPane.showMessageDialog(this,
                            "Game over! The number was " + targetNumber,
                            "Failed", JOptionPane.WARNING_MESSAGE);
                    startNewGame();
                } else {
                    hintLabel.setText(guess > targetNumber ? "Too high!" : "Too low!");
                }

            } catch (NumberFormatException ex) {
                hintLabel.setText("Enter a valid number!");
            }

        } else if (currentMode == GameMode.WORD) {
            if (input.equalsIgnoreCase(currentWord)) {
                hintLabel.setText("Correct! The word was " + currentWord);
                JOptionPane.showMessageDialog(this,
                        "Great job, " + playerName + "! You unscrambled the word.",
                        "Success!", JOptionPane.INFORMATION_MESSAGE);
                startNewGame();
            } else if (triesLeft <= 0) {
                hintLabel.setText("Out of tries! It was " + currentWord);
                JOptionPane.showMessageDialog(this,
                        "Game over! The word was " + currentWord,
                        "Failed", JOptionPane.WARNING_MESSAGE);
                startNewGame();
            } else {
                hintLabel.setText("Try again!");
            }
        }
    }

    private String scrambleWord(String word) {
        List<Character> chars = new ArrayList<>();
        for (char c : word.toCharArray()) chars.add(c);
        Collections.shuffle(chars);
        StringBuilder sb = new StringBuilder();
        for (char c : chars) sb.append(c);
        return sb.toString();
    }
}
