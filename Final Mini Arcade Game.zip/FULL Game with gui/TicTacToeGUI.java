
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TicTacToeGUI extends JFrame {
    private JButton[] buttons = new JButton[9];
    private char currentPlayer = 'X';

    public TicTacToeGUI() {
        setTitle("🎮 Tic Tac Toe");
        setSize(400, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridLayout(3, 3));
        mainPanel.setBackground(new Color(240, 255, 255)); // Azure background

        Font buttonFont = new Font("Comic Sans MS", Font.BOLD, 36);

        for (int i = 0; i < 9; i++) {
            buttons[i] = new JButton();
            buttons[i].setFont(buttonFont);
            buttons[i].setFocusPainted(false);
            buttons[i].setBackground((i + i / 3) % 2 == 0 ? new Color(255, 228, 225) : new Color(173, 216, 230)); // Rose and SkyBlue
            buttons[i].setForeground(Color.DARK_GRAY);
            buttons[i].addActionListener(e -> makeMove((JButton) e.getSource()));
            mainPanel.add(buttons[i]);
        }

        add(mainPanel);
    }

    private void makeMove(JButton button) {
        if (!button.getText().isEmpty()) return;

        button.setText(String.valueOf(currentPlayer));
        button.setForeground(currentPlayer == 'X' ? Color.RED : Color.BLUE);

        if (checkWin()) {
            JOptionPane.showMessageDialog(this, "🎉 Player " + currentPlayer + " wins!");
            dispose();
            return;
        }

        if (isBoardFull()) {
            JOptionPane.showMessageDialog(this, "🤝 Game Draw!");
            dispose();
            return;
        }

        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }

    private boolean checkWin() {
        for (int i = 0; i < 3; i++) {
            if (checkLine(i * 3, i * 3 + 1, i * 3 + 2)) return true; // Rows
            if (checkLine(i, i + 3, i + 6)) return true;             // Columns
        }
        return checkLine(0, 4, 8) || checkLine(2, 4, 6);              // Diagonals
    }

    private boolean checkLine(int a, int b, int c) {
        return !buttons[a].getText().isEmpty() &&
               buttons[a].getText().equals(buttons[b].getText()) &&
               buttons[b].getText().equals(buttons[c].getText());
    }

    private boolean isBoardFull() {
        for (JButton button : buttons) {
            if (button.getText().isEmpty()) {
                return false;
            }
        }
        return true;
    }
}
