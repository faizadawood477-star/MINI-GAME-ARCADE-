import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class RockPaperScissorsGUI extends JFrame {
    private JLabel resultLabel = new JLabel("Choose: [Rock______  | Paper______  | Scissors______ ]", SwingConstants.CENTER);
    private JLabel scoreLabel = new JLabel("Player: 0  Computer: 0", SwingConstants.CENTER);
    private String[] choices = {"✊Rock", "✋Paper", "✌Scissor"};
    private int playerScore = 0, computerScore = 0;
    private JPanel animationPanel;
    private Timer timer;
    private int animCount = 0;

    public RockPaperScissorsGUI() {
        setTitle("Rock Paper Scissors");
        setSize(400, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        resultLabel.setFont(new Font("Arial", Font.BOLD, 16));
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 18));

        // Animation panel with emoji drawing
        animationPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (timer != null && timer.isRunning()) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setFont(new Font("Segoe UI Emoji", Font.BOLD, 60));
                    g2.setColor(Color.BLACK);
                    String symbol = choices[animCount % 3];
                    FontMetrics fm = g2.getFontMetrics();
                    int x = (getWidth() - fm.stringWidth(symbol)) / 2;
                    int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
                    g2.drawString(symbol, x, y);
                }
            }
        };
        animationPanel.setPreferredSize(new Dimension(100, 100));

        // Buttons
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        for (String symbol : choices) {
            JButton btn = new JButton(symbol);
            btn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
            btn.addActionListener(e -> play(symbol));
            buttonPanel.add(btn);
        }

        add(scoreLabel, BorderLayout.NORTH);
        add(resultLabel, BorderLayout.CENTER);
        add(animationPanel, BorderLayout.EAST);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void play(String player) {
    animCount = 0;
    timer = new Timer(100, e -> {
        animCount++;
        animationPanel.repaint();

        if (animCount >= 10) {
            timer.stop();
            String computer = choices[new Random().nextInt(3)];
            String result;

            // Extract emoji for comparison
            String playerEmoji = player.substring(0, 1);
            String computerEmoji = computer.substring(0, 1);

            if (playerEmoji.equals(computerEmoji)) {
                result = "It's a tie!";
            } else if ((playerEmoji.equals("✊") && computerEmoji.equals("✌")) ||
                       (playerEmoji.equals("✋") && computerEmoji.equals("✊")) ||
                       (playerEmoji.equals("✌") && computerEmoji.equals("✋"))) {
                result = "You win!";
                playerScore++;
            } else {
                result = "Computer wins!";
                computerScore++;
            }

            scoreLabel.setText("Player: " + playerScore + "  Computer: " + computerScore);
            resultLabel.setText("You: " + player + " | Computer: " + computer + " → " + result);
        }
    });
    timer.start();
}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RockPaperScissorsGUI().setVisible(true));
    }
}



// import javax.swing.*;
// import java.awt.*;
// import java.awt.event.*;
// import java.util.Random;
// import java.nio.charset.Charset;  // Added this import

// public class RockPaperScissorsGUI extends JFrame {
//     private JLabel resultLabel, scoreLabel;
//     private int playerScore = 0, computerScore = 0;
//     private JButton rockBtn, paperBtn, scissorsBtn;
//     private JPanel animationPanel;
//     private Timer animationTimer;
//     private int animationCounter = 0;
//     private String[] choices = {"✊", "✋", "✌"};

//     public RockPaperScissorsGUI() {
//         setTitle("Rock Paper Scissors");
//         setSize(600, 500);
//         setLocationRelativeTo(null);
//         setDefaultCloseOperation(DISPOSE_ON_CLOSE);

//         // Try to set UTF-8 encoding for proper emoji display
//         try {
//             System.setProperty("file.encoding", "UTF-8");
//             java.lang.reflect.Field charset = Charset.class.getDeclaredField("defaultCharset");
//             charset.setAccessible(true);
//             charset.set(null, null);
//         } catch (Exception e) {
//             // If emojis don't work, we'll fall back to text
//             choices = new String[]{"✊Rock", "✋Paper", "✌Scissors"};
//         }

//         // Main panel with gradient background
//         JPanel mainPanel = new JPanel() {
//             @Override
//             protected void paintComponent(Graphics g) {
//                 super.paintComponent(g);
//                 Graphics2D g2d = (Graphics2D) g;
//                 g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
//                 GradientPaint gp = new GradientPaint(0, 0, new Color(106, 90, 205),
//                                                     0, getHeight(), new Color(30, 30, 60));
//                 g2d.setPaint(gp);
//                 g2d.fillRect(0, 0, getWidth(), getHeight());
//             }
//         };
//         mainPanel.setLayout(new BorderLayout());
//         mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

//         // Score label
//         scoreLabel = new JLabel("Player: 0  Computer: 0", SwingConstants.CENTER);
//         scoreLabel.setFont(new Font("Arial", Font.BOLD, 20));
//         scoreLabel.setForeground(Color.WHITE);
//         scoreLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

//         // Result label - using HTML for better text wrapping
//         resultLabel = new JLabel("<html><div style='text-align: center;'>Choose rock, paper, or scissors!</div></html>",
//                                SwingConstants.CENTER);
//         resultLabel.setFont(new Font("Arial", Font.BOLD, 24));
//         resultLabel.setForeground(Color.WHITE);
//         resultLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

//         // Animation panel
//         animationPanel = new JPanel() {
//             @Override
//             protected void paintComponent(Graphics g) {
//                 super.paintComponent(g);
//                 Graphics2D g2d = (Graphics2D) g;
//                 g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

//                 if (animationTimer != null && animationTimer.isRunning()) {
//                     // Try Segoe UI Emoji first, fall back to Arial if not available
//                     Font emojiFont = new Font("Segoe UI Emoji", Font.BOLD, 100);
//                     if (!emojiFont.getFontName().equals("Segoe UI Emoji")) {
//                         emojiFont = new Font("Arial", Font.BOLD, 100);
//                     }
//                     g2d.setFont(emojiFont);
//                     g2d.setColor(Color.WHITE);
//                     String text = choices[animationCounter % 3];
//                     FontMetrics fm = g2d.getFontMetrics();
//                     int x = (getWidth() - fm.stringWidth(text)) / 2;
//                     int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
//                     g2d.drawString(text, x, y);
//                 }
//             }
//         };
//         animationPanel.setPreferredSize(new Dimension(200, 200));
//         animationPanel.setOpaque(false);

//         // Button panel
//         JPanel buttonPanel = new JPanel();
//         buttonPanel.setOpaque(false);
//         buttonPanel.setLayout(new GridLayout(1, 3, 15, 15));
//         buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

//         // Create buttons with fallback to text if emojis don't work
//         rockBtn = createGameButton(choices[0], new Color(139, 69, 19));
//         paperBtn = createGameButton(choices[1], new Color(255, 255, 255));
//         scissorsBtn = createGameButton(choices[2], new Color(192, 192, 192));

//         rockBtn.addActionListener(e -> playGame(choices[0]));
//         paperBtn.addActionListener(e -> playGame(choices[1]));
//         scissorsBtn.addActionListener(e -> playGame(choices[2]));

//         buttonPanel.add(rockBtn);
//         buttonPanel.add(paperBtn);
//         buttonPanel.add(scissorsBtn);

//         // Main layout
//         mainPanel.add(scoreLabel, BorderLayout.NORTH);
//         mainPanel.add(resultLabel, BorderLayout.CENTER);
//         mainPanel.add(animationPanel, BorderLayout.WEST);
//         mainPanel.add(buttonPanel, BorderLayout.SOUTH);

//         add(mainPanel);
//     }

//     private JButton createGameButton(String text, Color bgColor) {
//         JButton button = new JButton(text) {
//             @Override
//             protected void paintComponent(Graphics g) {
//                 Graphics2D g2 = (Graphics2D) g.create();
//                 g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//                 g2.setColor(bgColor);
//                 g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
//                 g2.setColor(Color.BLACK);
//                 // Try Segoe UI Emoji first, fall back to Arial if not available
//                 Font emojiFont = new Font("Segoe UI Emoji", Font.BOLD, 60);
//                 if (!emojiFont.getFontName().equals("Segoe UI Emoji")) {
//                     emojiFont = new Font("Arial", Font.BOLD, 60);
//                 }
//                 g2.setFont(emojiFont);
//                 FontMetrics fm = g2.getFontMetrics();
//                 int x = (getWidth() - fm.stringWidth(getText())) / 2;
//                 int y = ((getHeight() - fm.getHeight()) / 2) + fm.getAscent();
//                 g2.drawString(getText(), x, y);
//                 g2.dispose();
//             }
//         };
//         button.setContentAreaFilled(false);
//         button.setBorderPainted(false);
//         button.setPreferredSize(new Dimension(100, 100));
//         button.setFocusPainted(false);
//         button.setCursor(new Cursor(Cursor.HAND_CURSOR));
//         return button;
//     }

//     private void playGame(String playerChoice) {
//         // Disable buttons during animation
//         rockBtn.setEnabled(false);
//         paperBtn.setEnabled(false);
//         scissorsBtn.setEnabled(false);

//         // Start animation
//         animationCounter = 0; // Reset counter
//         animationTimer = new Timer(100, e -> {
//             animationCounter++;
//             animationPanel.repaint();

//             if (animationCounter >= 10) { // After 10 animation frames
//                 animationTimer.stop();

//                 // Computer makes random choice
//                 Random rand = new Random();
//                 String computerChoice = choices[rand.nextInt(3)];

//                 // Determine winner
//                 String result;
//                 if (playerChoice.equals(computerChoice)) {
//                     result = "It's a tie!";
//                 } else if ((playerChoice.equals(choices[0]) && computerChoice.equals(choices[2])) ||
//                           (playerChoice.equals(choices[1]) && computerChoice.equals(choices[0])) ||
//                           (playerChoice.equals(choices[2]) && computerChoice.equals(choices[1]))) {
//                     result = "You win!";
//                     playerScore++;
//                 } else {
//                     result = "Computer wins!";
//                     computerScore++;
//                 }

//                 // Update UI with HTML for proper text wrapping
//                 scoreLabel.setText("Player: " + playerScore + "  Computer: " + computerScore);
//                 resultLabel.setText("<html><div style='text-align: center;'>You chose " + playerChoice +
//                                   ", Computer chose " + computerChoice + ".<br>" + result + "</div></html>");

//                 // Re-enable buttons
//                 rockBtn.setEnabled(true);
//                 paperBtn.setEnabled(true);
//                 scissorsBtn.setEnabled(true);
//             }
//         });
//         animationTimer.start();
//     }

//     public static void main(String[] args) {
//         SwingUtilities.invokeLater(() -> {
//             RockPaperScissorsGUI game = new RockPaperScissorsGUI();
//             game.setVisible(true);
//         });
//     }
// }
