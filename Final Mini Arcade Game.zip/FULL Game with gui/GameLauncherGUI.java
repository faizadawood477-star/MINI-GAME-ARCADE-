import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GameLauncherGUI extends JFrame {
    public GameLauncherGUI() {
        setTitle("🎮 Mini Game Arcade");
        setSize(800, 500); // Increased size to accommodate larger cards
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center window

        // Title panel with no background (transparent) and larger text
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(new Color(0, 0, 0, 0)); // Transparent background
        JLabel titleLabel = new JLabel(" Mini Game Arcade", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Verdana", Font.BOLD, 40)); // Increased font size
        titleLabel.setForeground(new Color(76, 175, 80)); // Lighter green (#4CAF50)
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        add(titlePanel, BorderLayout.NORTH);

        // Main panel with background color and centered layout
        JPanel mainPanel = new JPanel(new GridBagLayout()); // Using GridBagLayout for centering
        mainPanel.setBackground(new Color(30, 30, 60)); // Dark blue-ish
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Outer padding

        // Create a panel to hold the 2x2 grid of cards
        JPanel cardContainer = new JPanel(new GridLayout(2, 2, 20, 20)); // 2x2 grid with 20px spacing
        cardContainer.setBackground(new Color(30, 30, 60)); // Match background
        cardContainer.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50)); // Inner padding for centering

        // Create card panels for each game with larger size
        JPanel quizCard = createCard("Play Quiz Game", new Color(255, 111, 97), e -> {
            new QuizGameGUI().setVisible(true);
        });
        JPanel rpsCard = createCard("Play Rock Paper Scissors", new Color(106, 90, 205), e -> {
            new RockPaperScissorsGUI().setVisible(true);
        });
        JPanel guessCard = createCard("Play Random Guessing Game", new Color(46, 139, 87), e -> {
            String name = JOptionPane.showInputDialog(GameLauncherGUI.this, "Enter your name:");
            if (name != null && !name.trim().isEmpty()) {
                new RandomGuessingGameGUI(name.trim()).setVisible(true);
            }
        });
        JPanel tttCard = createCard("Play Tic Tac Toe", new Color(255, 165, 0), e -> {
            new TicTacToeGUI().setVisible(true);
        });

        // Add cards to card container
        cardContainer.add(quizCard);
        cardContainer.add(rpsCard);
        cardContainer.add(guessCard);
        cardContainer.add(tttCard);

        // Add card container to main panel with centering
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(cardContainer, gbc);

        add(mainPanel, BorderLayout.CENTER);
    }

    private JPanel createCard(String text, Color color, ActionListener action) {
        JPanel card = new JPanel(new BorderLayout());
        card.setPreferredSize(new Dimension(400, 170)); // Increased card size to 300x150
        card.setBackground(color);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10))); // Increased padding

        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 20)); // Increased font size
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false); // Transparent button background
        button.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Increased border
        button.addActionListener(action);

        // Center the button in the card
        card.add(button, BorderLayout.CENTER);

        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setForeground(color.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setForeground(Color.WHITE);
            }
        });

        return card;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GameLauncherGUI().setVisible(true));
    }
}
